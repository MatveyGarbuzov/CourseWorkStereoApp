////
////  qwert.swift
////  CourseWorkStereoApp
////
////  Created by Matvey Garbuzov on 15.04.2023.
////
//
//import UIKit
//import SnapKit
//import CoreMotion
//import AVFoundation
//
//class HomeViewController2: UIViewController {
//  let audioField = AudioSpace()
//  lazy var audioFieldView = AudioSpaceView(space: audioField)
//  let button = UIButton()
//  
//  let pickerView = AudioPickerView(files: files)
//  let motion = CMHeadphoneMotionManager()
//  
//  var emptyPlayer: AVAudioPlayer?
//  var timer: Timer?
//  
//  override func viewDidLoad() {
//    super.viewDidLoad()
//    
//    setupConstraints()
//    setup()
//  }
//  
//  func setupConstraints() {
//    view.backgroundColor = UIColor.Theme.mainBG
//    
//    view.addSubview(audioFieldView)
//    view.addSubview(pickerView)
//    view.addSubview(button)
//    
//    audioFieldView.snp.makeConstraints { make in
//      make.top.equalTo(view.safeAreaLayoutGuide)
//      make.left.right.equalToSuperview().inset(30)
//      make.height.equalTo(audioFieldView.snp.width)
//      make.centerX.equalToSuperview()
//    }
//    
//    pickerView.backgroundColor = .orange
//    pickerView.snp.makeConstraints { make in
//      make.top.equalTo(audioFieldView.snp.bottom).offset(10)
//      make.left.right.equalToSuperview().inset(30)
//      make.bottom.equalTo(view.safeAreaLayoutGuide).inset(140)
//      make.centerX.equalToSuperview()
//    }
//    
//    button.snp.makeConstraints { make in
//      make.height.equalTo(30)
//      make.left.right.equalToSuperview().inset(100)
//      make.top.equalTo(pickerView.snp.bottom).offset(20)
//      make.centerX.equalToSuperview()
//    }
//    button.addTarget(self, action: #selector(saveButtonPressed), for: .touchUpInside)
//    button.backgroundColor = .red
//    button.setTitle("123wq", for: .normal)
//  }
//  
//  
//  
//  @objc func saveButtonPressed(sender: UIButton) {
//    print("Current sources: \(audioField.sources)")
//  }
//  
//  func setup() {
//    self.timer = Timer(timeInterval: 0.3, repeats: true) { _ in
//    }
//    RunLoop.current.add(self.timer!, forMode: .common)
//    self.pickerView.fileClickedAction = { [weak self] file in
//      let audioSource = AudioSource(
//        audio: file,
//        point: CGPoint(
//          x: CGFloat.random(in: 0.1..<0.9),
//          y: CGFloat.random(in: 0.1..<0.9)
//        ),
//        range: 0.5
//      )
//      self?.audioField.addSource(audioSource: audioSource)
//    }
//
//    guard self.motion.isDeviceMotionAvailable else { return }
//
//    self.motion.startDeviceMotionUpdates(to: OperationQueue.main, withHandler: {[weak self] motion, error  in
//        guard let motion = motion, error == nil else { return }
//        self?.processData(motion)
//    })
//  }
//  
//  func processData(_ data: CMDeviceMotion) {
//    let angle = CGFloat(data.attitude.yaw)
//    self.audioField.yaw = angle
//    
//    let deg = angle * CGFloat(180.0 / Double.pi)
//    print(deg)
//  }
//}
//
