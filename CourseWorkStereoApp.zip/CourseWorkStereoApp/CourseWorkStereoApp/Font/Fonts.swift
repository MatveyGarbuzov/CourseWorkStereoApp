//
//  Fonts.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 16.04.2023.
//

import UIKit

extension UIFont {
  enum CustomFont {
    case interBold(size: CGFloat)
    case interMedium(size: CGFloat)
    case interRegular(size: CGFloat)
    case interSemiBold(size: CGFloat)
    case interLight(size: CGFloat)
    
    var font: UIFont! {
      switch self {
      case .interBold(size: let size):
        return UIFont(name: "Inter-Bold", size: size)
      case .interMedium(let size):
        return UIFont(name: "Inter-Medium", size: size)
      case .interRegular(size: let size):
        return UIFont(name: "Inter-Regular", size: size)
      case .interSemiBold(size: let size):
        return UIFont(name: "Inter-SemiBold", size: size)
      case .interLight(size: let size):
        return UIFont(name: "Inter-Light", size: size)
      }
    }
  }
}

