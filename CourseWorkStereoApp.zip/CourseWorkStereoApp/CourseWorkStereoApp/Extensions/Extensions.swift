//
//  Extensions.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 12.04.2023.
//

import UIKit

extension UIView {
  func roundCorners(corners: UIRectCorner, radius: CGFloat) {
    let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
    let mask = CAShapeLayer()
    mask.path = path.cgPath
    layer.mask = mask
  }
}

extension UIColor {
  struct Theme {
    static let mainBG = UIColor(named: "MainBG")
    static let additionalBG = UIColor(named: "AdditionalBG")
    static let yellow = UIColor(named: "Yellow")
    static let text = UIColor(named: "Text")
    static let labelText = UIColor(named: "LabelText")
    static let user = UIColor(named: "User")
    static let profileSubscription = UIColor(named: "ProfileSubscription")
    
  }
}

extension UIView {
    func addDropShadow() {
      layer.shadowColor = UIColor.black.cgColor
      layer.shadowOffset = CGSize(width: 2, height: 2)
      layer.shadowOpacity = 0.25
      layer.shadowRadius = 3.0
    }
}
