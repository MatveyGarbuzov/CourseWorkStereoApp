//
//  Animations.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 12.04.2023.
//

import UIKit

extension UIView {
  func animateOutsidePress() {
    UIView.animate(withDuration: 0.15, animations: {
      self.transform = self.transform.scaledBy(x: 1.05, y: 1.05)
    }) { _ in
      UIView.animate(withDuration: 0.15, animations: {
        self.transform = CGAffineTransform.identity
      })
    }
  }
  
  func animateOutsidePress(withInDuration inDuration: TimeInterval = 0.2,
                           withOutDuration outDuration: TimeInterval = 0.2,
                           scaledByX x: CGFloat = 1.1,
                           scaledByY y: CGFloat = 1.1) {
    UIView.animate(withDuration: inDuration, animations: {
      self.transform = self.transform.scaledBy(x: x, y: y)
    }) { _ in
      UIView.animate(withDuration: outDuration, animations: {
        self.transform = CGAffineTransform.identity
      })
    }
  }
  
  func animateInsidePress() {
    UIView.animate(withDuration: 0.15, animations: {
      self.transform = self.transform.scaledBy(x: 0.95, y: 0.95)
    }) { _ in
      UIView.animate(withDuration: 0.15, animations: {
        self.transform = CGAffineTransform.identity
      })
    }
  }
  
  func animateInsidePress(withInDuration inDuration: TimeInterval = 0.2,
                           withOutDuration outDuration: TimeInterval = 0.2,
                          scaledByX x: CGFloat = 0.9,
                          scaledByY y: CGFloat = 0.9) {
    UIView.animate(withDuration: inDuration, animations: {
      self.transform = self.transform.scaledBy(x: x, y: y)
    }) { _ in
      UIView.animate(withDuration: outDuration, animations: {
        self.transform = CGAffineTransform.identity
      })
    }
  }
  
  func shake() {
      let animation = CABasicAnimation(keyPath: "position")
      animation.duration = 0.1
      animation.repeatCount = 1
      animation.autoreverses = true
      animation.fromValue = NSValue(cgPoint: CGPoint(x: self.center.x - 4, y: self.center.y))
      animation.toValue = NSValue(cgPoint: CGPoint(x: self.center.x + 4, y: self.center.y))
      self.layer.add(animation, forKey: "position")
    }

}

//
//extension UIView {
//  func addRunningDotAnimation(color: UIColor, duration: Double, dotSize: CGFloat) {
//    let animation = CAKeyframeAnimation(keyPath: "position")
//    animation.path = UIBezierPath(ovalIn: bounds).cgPath
//    animation.duration = duration
//    animation.repeatCount = .infinity
//
//    let maxDotSize = min(bounds.width, bounds.height) // Ensure dot fits within view bounds
//    let actualDotSize = min(maxDotSize, dotSize)
//
//    let dotLayer = CALayer()
//    dotLayer.frame = CGRect(x: 0, y: 0, width: actualDotSize, height: actualDotSize)
//    dotLayer.cornerRadius = actualDotSize / 2
//    dotLayer.backgroundColor = color.cgColor
//    dotLayer.add(animation, forKey: "runningDot")
//
//    // Position the dot layer at the start of the animation path
//    let startPoint = CGPoint(x: bounds.midX + (bounds.width / 2), y: bounds.midY)
//    dotLayer.position = startPoint
//
//    layer.insertSublayer(dotLayer, at: 0)
//  }
//
//
//  func addPerimeterAnimation(color: UIColor, duration: Double) {
//    let animation = CAKeyframeAnimation(keyPath: "position")
//
//    // Define the path for the animation
//    let path = UIBezierPath()
//    path.move(to: CGPoint(x: bounds.minX + 5, y: bounds.minY + 5))
//    path.addLine(to: CGPoint(x: bounds.maxX - 5, y: bounds.minY + 5))
//    path.addLine(to: CGPoint(x: bounds.maxX - 5, y: bounds.maxY - 5))
//    path.addLine(to: CGPoint(x: bounds.minX + 5, y: bounds.maxY - 5))
//    path.close()
//
//    animation.path = path.cgPath
//    animation.duration = duration
//    animation.repeatCount = .infinity
//
//    let dotLayer = CALayer()
//    dotLayer.frame = CGRect(x: 0, y: 0, width: 50, height: 20)
//    dotLayer.cornerRadius = 10
//    dotLayer.backgroundColor = color.cgColor
//    dotLayer.add(animation, forKey: "perimeterAnimation")
//
//    layer.insertSublayer(dotLayer, at: 0)
//  }
//}
