//
//  AudioFile.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 14.04.2023.
//

import Foundation
import AVFoundation
import UIKit

struct AudioFile: Codable, Equatable {
  enum File: String, Codable {
    case mp3
    case wav
    
    var type: AVFileType {
      switch self {
      case .mp3:
        return AVFileType.mp3
      case .wav:
        return AVFileType.wav
      }
    }
  }
  
  var name: String
  var file: File
  var iconString: String
  
  var icon: UIImage? {
    return UIImage(systemName: iconString)
  }
  
  private enum CodingKeys: String, CodingKey {
    case name
    case file
    case iconString = "icon"
  }
  
  static var baraban: AudioFile {
    return AudioFile(name: "baraban_music", file: .mp3, iconString: "music.note")
  }
  
  static var baraban2: AudioFile {
    return AudioFile(name: "baraban2_music", file: .mp3, iconString: "music.note")
  }
  
  static var bell: AudioFile {
    return AudioFile(name: "bell_music", file: .mp3, iconString: "music.note")
  }
  
  static var bird: AudioFile {
    return AudioFile(name: "bird_music", file: .mp3, iconString: "music.note")
  }
  
  static var chimeBar: AudioFile {
    return AudioFile(name: "chimeBar_music", file: .mp3, iconString: "music.note")
  }
  
  static var dog: AudioFile {
    return AudioFile(name: "dog_music", file: .mp3, iconString: "music.note")
  }
  
  static var forest: AudioFile {
    return AudioFile(name: "forest_music", file: .mp3, iconString: "music.note")
  }
  
  static var guitar: AudioFile {
    return AudioFile(name: "guitar_music", file: .mp3, iconString: "music.note")
  }
  
  static var guitar2: AudioFile {
    return AudioFile(name: "guitar2_music", file: .mp3, iconString: "music.note")
  }
  
  static var piano: AudioFile {
    return AudioFile(name: "piano_music", file: .mp3, iconString: "music.note")
  }
  
  static var solMi: AudioFile {
    return AudioFile(name: "solMi_Music", file: .mp3, iconString: "music.note")
  }
  
  static var violin: AudioFile {
    return AudioFile(name: "violin_music", file: .mp3, iconString: "music.note")
  }

}

