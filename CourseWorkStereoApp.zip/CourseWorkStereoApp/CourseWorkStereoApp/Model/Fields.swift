//
//  Base.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 16.04.2023.
//

import Foundation
import UIKit

class Fields {
  let defaults = UserDefaults.standard
  static let shared = Fields() // Singleton
  
  struct Sources: Codable {
    var nameOfField: String = "Unknown"
    var fieldOfSources: [AudioSource]
  }
  
  var savedFieldsOfSources:[Sources] {
    get {
      if let data = defaults.value(forKey: "savedFieldsOfSources") as? Data {
        return try! PropertyListDecoder().decode([Sources].self, from: data)
      } else {
        return [Sources]()
      }
    }
    
    set {
      if let data = try? PropertyListEncoder().encode(newValue) {
        defaults.set(data, forKey: "savedFieldsOfSources")
      }
    }
  }
  
  func saveField(nameOfField: String, fieldOfSources: [AudioSource]) {
    let field = Sources(nameOfField: nameOfField, fieldOfSources: fieldOfSources)
    
    savedFieldsOfSources.insert(field, at: 0)
  }
  
  func updateField(nameOfField: String, fieldOfSources: [AudioSource], index: Int) {
    print("UPDATE FIELD")
    let updatedField = Sources(nameOfField: nameOfField, fieldOfSources: fieldOfSources)
    
    savedFieldsOfSources[index] = updatedField
  }
  
  func deleteField(at index: Int) {
    savedFieldsOfSources.remove(at: index)
  }
}

//class Profile {
//  let defaults = UserDefaults.standard
//  static let shared = Profile()
//
//  struct ProfileData: Codable {
//    var imageData: Data
//    var name: String
//    var signature: String
//    var description: String
//
//    var image: UIImage? {
//        get {
//          return UIImage(data: imageData)
//        }
//        set {
//          if let image = newValue {
//            imageData = image.pngData()!
//          }
//        }
//      }
//
//  }
//
//
//  var profileInfo: ProfileData? {
//    get {
//      if let data = defaults.value(forKey: "profileInfo") as? Data {
//        return try! PropertyListDecoder().decode(ProfileData.self, from: data)
//      } else {
//        return nil
//      }
//    }
//    set {
//      if let data = try? PropertyListEncoder().encode(newValue) {
//        defaults.set(data, forKey: "profileInfo")
//      }
//    }
//  }
//
//}

class Profile {
  let defaults = UserDefaults.standard
  static let shared = Profile()
  
  struct ProfileData: Codable {
    var imageData: Data
    var name: String
    var signature: String
    var description: String
    
    enum CodingKeys: String, CodingKey {
      case imageData
      case name
      case signature
      case description
    }
    
    var image: UIImage? {
      get {
        return UIImage(data: imageData)
      }
      set {
        if let image = newValue {
          imageData = image.pngData()!
        }
      }
    }
    
    init(image: UIImage?, name: String, signature: String, description: String) {
      self.imageData = image?.pngData() ?? Data()
      self.name = name
      self.signature = signature
      self.description = description
    }
  }
  
  var profileInfo: ProfileData? {
    get {
      if let data = defaults.value(forKey: "profileInfo") as? Data {
        return try? JSONDecoder().decode(ProfileData.self, from: data)
      } else {
        return nil
      }
    }
    set {
      if let data = try? JSONEncoder().encode(newValue) {
        defaults.set(data, forKey: "profileInfo")
      } else {
        defaults.removeObject(forKey: "profileInfo")
      }
    }
  }
  
  private init() {}
}
