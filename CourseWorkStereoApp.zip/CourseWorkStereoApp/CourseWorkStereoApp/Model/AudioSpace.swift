//
//  AmbientAudioField.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 14.04.2023.
//

import UIKit
//import Combine

protocol AudioSpaceDelegate: AnyObject {
  func addAudioSource(audioSource: AudioSource)
  func removeAudioSource(audioSource: AudioSource)
}

class AudioSpace {
  /*private(set)*/ var sources: [AudioSource] = []
  weak var delegate: AudioSpaceDelegate?
  
  var yaw: CGFloat = 0 {
    didSet {
      self.sources.forEach({ $0.yaw = self.yaw })
    }
  }
  
  func addSource(audioSource: AudioSource) {
    self.sources.append(audioSource)
    self.delegate?.addAudioSource(audioSource: audioSource)
    print("Current sources: \(sources)")
  }
  
  func removeSource(audioSource: AudioSource) {
    print("PREPARE TO REMOVE")
    audioSource.stopAudio()
    self.sources.removeAll(where: { $0 === audioSource })
    self.delegate?.removeAudioSource(audioSource: audioSource)
    print("Current sources: [", terminator: " ")
    for i in 0..<sources.count {
      print(sources[i].audio.name, terminator: " ")
    }
    print("]", terminator: " ")
  }
}

