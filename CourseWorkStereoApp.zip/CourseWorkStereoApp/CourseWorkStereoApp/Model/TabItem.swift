//
//  TabItem.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 12.04.2023.
//

import UIKit

enum TabItem: String, CaseIterable {
  case home = "home"
  case saved = "saved"
  case profile = "profile"
  
  var viewController: UIViewController {
    switch self {
    case .home:
      return HomeViewController()
    case .saved:
      return SavedViewController()
    case .profile:
      return ProfileViewController()
    }
  }
  
  // these can be your icons
  var icon: UIImage {
    switch self {
    case .home:
      return UIImage(named: "homeIcon")!
    case .saved:
      return UIImage(named: "savedIcon")!
    case .profile:
      return UIImage(named: "profileIcon")!
    }
  }
  var displayTitle: String {
    return self.rawValue.capitalized(with: nil)
  }
}
