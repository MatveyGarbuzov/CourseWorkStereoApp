//
//  CircleImageView.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 14.04.2023.
//

import UIKit
//
//class CircleImage: UIImageView {
//  override func layoutSubviews() {
//    super.layoutSubviews()
//    
//    self.clipsToBounds = true
//    self.layer.cornerRadius = self.frame.size.height / 2
//  }
//}

