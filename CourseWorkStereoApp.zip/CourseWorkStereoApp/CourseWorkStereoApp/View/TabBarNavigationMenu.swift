//
//  TabBarNavigationMenu.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 12.04.2023.
//

import UIKit
import SnapKit

class TabNavigationMenu: UIImageView {
  var itemTapped: ((_ tab: Int) -> Void)?
  var activeItem: Int = 0
  
  override init(frame: CGRect) {
    super.init(frame: frame)
  }
  
  required init?(coder aDecoder: NSCoder) {
    super.init(coder: aDecoder)
  }
  
  convenience init(menuItems: [TabItem], frame: CGRect) {
    self.init(frame: frame)
    self.isUserInteractionEnabled = true
    self.clipsToBounds = true
    
    for i in 0 ..< menuItems.count {
      let itemWidth = self.frame.width / CGFloat(menuItems.count)
      let leadingAnchor = itemWidth * CGFloat(i)
      
      let itemView = self.createTabItem(item: menuItems[i])
      itemView.tag = i
      
      itemView.clipsToBounds = true
      self.addSubview(itemView)
      itemView.snp.makeConstraints { make in
        make.height.top.equalToSuperview()
        make.width.equalTo(itemWidth)
        make.leading.equalTo(self.snp.leading).offset(leadingAnchor)
      }
    }
    self.backgroundColor = UIColor.Theme.additionalBG
    self.setNeedsLayout()
    self.layoutIfNeeded()
    self.activateTab(tab: 0)
    roundCorners(corners: [.topLeft, .topRight], radius: 25)
  }
  
  func createTabItem(item: TabItem) -> UIView {
    let tabBarItem = UIView(frame: CGRect.zero)
    let itemIconView = UIImageView(frame: CGRect.zero)
    let selectedItemView = UIImageView(frame: CGRect.zero)
    
    // adding tags to get views for modification when selected/unselected
    tabBarItem.tag = 11
    itemIconView.tag = 12
    selectedItemView.tag = 13
    
    selectedItemView.image = UIImage(named: "selected")!.withRenderingMode(.alwaysTemplate)
    selectedItemView.tintColor = UIColor.Theme.yellow
    selectedItemView.clipsToBounds = true
    tabBarItem.addSubview(selectedItemView)
    selectedItemView.snp.makeConstraints { make in
      make.center.equalToSuperview()
      make.height.width.equalTo(40)
    }
    
    selectedItemView.layer.cornerRadius = 10
    tabBarItem.sendSubviewToBack(selectedItemView)
    
    selectedItemView.isHidden = true
    
    itemIconView.image = item.icon.withRenderingMode(.automatic)
    itemIconView.contentMode = .scaleAspectFit
    itemIconView.clipsToBounds = true
    tabBarItem.clipsToBounds = true
    tabBarItem.layer.backgroundColor = UIColor.clear.cgColor
    tabBarItem.addSubview(itemIconView)
    itemIconView.snp.makeConstraints { make in
      make.center.equalTo(selectedItemView)
      make.height.width.equalTo(17)
    }
    tabBarItem.addGestureRecognizer(UITapGestureRecognizer(
      target: self,
      action: #selector(self.handleTap)
    ))
    return tabBarItem
  }
  
  @objc func handleTap(_ sender: UIGestureRecognizer) {
    self.switchTab(from: self.activeItem, to: sender.view!.tag)
  }
  
  func switchTab(from: Int, to: Int) {
    // Check if tab is already chosen
    print("FROM: \(from) TO:\(to)")
    if from != to {
      self.deactivateTab(tab: from)
      self.activateTab(tab: to)
    } else {
      animateAlreadyChosenTab(tab: to)
    }
  }
  
  func animateAlreadyChosenTab(tab: Int) {
    let tabToActivate = self.subviews[tab]

    tabToActivate.animateOutsidePress(withInDuration: 0.25, withOutDuration: 0.25, scaledByX: 1.2, scaledByY: 1.2)
    tabToActivate.isHidden = false
    self.layoutIfNeeded()
  }
  
  func activateTab(tab: Int) {
    let tabToActivate = self.subviews[tab]
    
    // showing selection
    tabToActivate.viewWithTag(13)?.isHidden = false // showing selected tab background
    
    // transform effect for selectedTab background
    UIView.animate(withDuration: 0.25, animations: {
      tabToActivate.viewWithTag(13)?.animateOutsidePress(scaledByX: 1, scaledByY: 1)
      self.layoutIfNeeded()
    }) { (Bool) in
      tabToActivate.viewWithTag(13)?.isHidden = false
    }
    
    self.itemTapped?(tab)
    self.activeItem = tab
  }
  
  func deactivateTab(tab: Int) {
    let inactiveTab = self.subviews[tab]
    
    // changing constraints for animation
    NSLayoutConstraint.deactivate(inactiveTab.constraints.filter({$0.firstItem === inactiveTab.viewWithTag(12) && $0.firstAttribute == .centerX}))
    NSLayoutConstraint.activate([inactiveTab.viewWithTag(12)!.centerXAnchor.constraint(equalTo: inactiveTab.centerXAnchor)])
    
    self.layoutIfNeeded()
    UIView.animate(withDuration: 0.25, animations: {
      inactiveTab.viewWithTag(13)?.transform = CGAffineTransform(scaleX: 0.01, y: 0.01)
      self.layoutIfNeeded()
    }) { (Bool) in
      inactiveTab.viewWithTag(13)?.isHidden = true
    }
  }
}
