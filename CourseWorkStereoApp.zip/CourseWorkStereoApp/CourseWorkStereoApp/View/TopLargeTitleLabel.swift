//
//  TopLargeTitleLabel.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 12.04.2023.
//

import UIKit

class TopLargeTitleLabel: UILabel {
  func setup() {
    textAlignment = .center
    textColor = UIColor.Theme.text
//    font = UIFont(name: "Montserrat-SemiBold", size: 27)
  }
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    setup()
  }
  
  required init?(coder: NSCoder) {
    super.init(coder: coder)
    setup()
  }
}
