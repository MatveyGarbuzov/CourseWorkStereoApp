//
//  AudioFileView.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 14.04.2023.
//

import UIKit

class AudioFileView: UIControl {
  let file: AudioFile
  let imageView = UIImageView()
  
  init(file: AudioFile) {
    self.file = file
    super.init(frame: .zero)
    self.setup()
    addDropShadow()
  }
  
  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func setup() {
    self.addSubview(self.imageView)
    self.imageView.isUserInteractionEnabled = false
    self.imageView.snp.makeConstraints { make in
      make.edges.equalToSuperview()
    }
    self.backgroundColor = UIColor.Theme.additionalBG
    
    self.imageView.tintColor = UIColor.Theme.user
    self.imageView.image = self.file.icon?.withRenderingMode(.alwaysTemplate)
  }
}


