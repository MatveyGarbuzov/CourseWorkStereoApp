//
//  AudioFieldView.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 14.04.2023.
//

import UIKit
import SnapKit

class AudioSpaceView: UIView, AudioSpaceDelegate {
  var space: AudioSpace
  var backgroundView = UIView()
  var userImageView = UserView()
  var audioSpaceNodes: [AudioSpaceNodeView] = []
  
  init(space: AudioSpace) {
    self.space = space
    super.init(frame: .zero)
    self.setup()
  }
    
  func update(with sources: [AudioSource]) {
    self.clearField()
    self.space.sources = sources
    self.setup()
    self.space.sources.forEach { $0.runAudio() }
  }
  
  func clearField() {
    self.space.sources.forEach {
      self.removeAudioSource(audioSource: $0)
    }
    self.audioSpaceNodes.forEach { $0.removeFromSuperview() }
  }
  
  func addAudioSource(audioSource: AudioSource) {
    let node = AudioSpaceNodeView()
    node.source = audioSource
    self.audioSpaceNodes.append(node)
    self.backgroundView.addSubview(node)
    
    self.updatePosition(node: node, audioSource: audioSource)
    
    if audioSource.addAnimation {
      node.playFallAnimation()
    }
    
    self.lastAddedNode = node
  }
  
  func removeAudioSource(audioSource: AudioSource) {
      audioSource.stopAudio()
    guard let node = self.audioSpaceNodes.first(where: { $0.source == audioSource }) else {
      return
    }
    self.audioSpaceNodes.removeAll(where: { $0 == node })
    node.removeFromSuperview()
  }
  
  func updatePosition(node: AudioSpaceNodeView, audioSource: AudioSource) {
    node.center = audioSource.convert(fullSize: self.frame.size)
  }
  
  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  var timer: Timer?
  
  func setup() {
    self.addSubview(self.backgroundView)
    self.addDropShadow()
    self.backgroundView.layer.cornerRadius = 12
    self.backgroundView.layer.masksToBounds = true
    self.backgroundView.backgroundColor = UIColor.Theme.additionalBG
    
    self.backgroundView.snp.makeConstraints { make in
      make.edges.equalToSuperview()
      make.width.equalTo(self.snp.height)
    }
    
    self.backgroundView.addSubview(self.userImageView)
    self.userImageView.snp.makeConstraints { make in
      make.center.equalToSuperview()
      make.height.width.equalTo(30)
//      make.size.equalTo(34)
    }
    for source in self.space.sources {
      self.addAudioSource(audioSource: source)
    }
    self.space.delegate = self
    
    self.timer = Timer(timeInterval: 0.9, repeats: true, block: { _ in
      //            self.gradientView.animate()
    })
    RunLoop.current.add(self.timer!, forMode: .common)
  }
  
  var selectedNode: AudioSpaceNodeView?
  weak var lastAddedNode: AudioSpaceNodeView?
  
  override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    print("BEGAN")
    super.touchesBegan(touches, with: event)
    self.selectedNode = nil
    
    guard let touch = touches.first else {
      return
    }
    
    let position = touch.location(in: self)
    
    for node in self.audioSpaceNodes {
      if node.frame.contains(position) {
        self.selectedNode = node
        node.selected = true
        break
      }
    }
  }
  
  override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
    print("MOVED")
    super.touchesMoved(touches, with: event)
    
    guard let touch = touches.first,
          let selectedNode = self.selectedNode else {
      return
    }
    
    let position = touch.location(in: self)
    var itemFrame = CGRect(
      x: position.x - selectedNode.frame.width / 2,
      y: position.y - selectedNode.frame.height / 2,
      width: selectedNode.frame.width,
      height: selectedNode.frame.height
    )
    
    let percentage = self.bounds.intersectionPercentage(itemFrame)
    if percentage != 0 {
      if itemFrame.origin.x < 0 {
        itemFrame.origin.x = 0
      }
      
      if itemFrame.origin.y < 0 {
        itemFrame.origin.y = 0
      }
      
      if itemFrame.maxX > self.frame.width {
        itemFrame.origin.x = self.frame.width - itemFrame.width
      }
      
      if itemFrame.maxY > self.frame.height {
        itemFrame.origin.y = self.frame.height - itemFrame.height
      }
      
      selectedNode.center = CGPoint(
        x: itemFrame.midX,
        y: itemFrame.midY
      )
      selectedNode.prepareToRemove = false
    } else {
      selectedNode.center = position
      selectedNode.prepareToRemove = true
    }
    
    selectedNode.source?.applyFrom(
      viewPoint: selectedNode.center,
      insideSize: self.bounds.size
    )
  }
  
  override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
    print("END")
    super.touchesEnded(touches, with: event)
    self.touchEndActions()
  }
  
  override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
    print("CANCELLED")
    super.touchesCancelled(touches, with: event)
    self.touchEndActions()
  }
  
  private func touchEndActions() {
    print("END_Actions")
    self.selectedNode?.selected = false
    if self.selectedNode?.prepareToRemove == true, let source = self.selectedNode?.source {
      self.space.removeSource(audioSource: source)
    }
    self.selectedNode = nil
  }
}

public extension CGRect {
  func intersectionPercentage(_ otherRect: CGRect) -> CGFloat {
    if !intersects(otherRect) { return 0 }
    let intersectionRect = intersection(otherRect)
    if intersectionRect == self || intersectionRect == otherRect { return 100 }
    let intersectionArea = intersectionRect.width * intersectionRect.height
    let area = width * height
    return (intersectionArea / area) * 100
  }
}


