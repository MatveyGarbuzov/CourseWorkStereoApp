//
//  AudioListView.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 14.04.2023.
//

import UIKit

class AudioPickerView: UIView {
  let files: [AudioFile]
  
  var fileClickedAction: ((AudioFile) -> Void)?
  var audioSpaceView: AudioSpaceView?
  
  let mainVStack = UIStackView()
  
  var fileViews: [AudioFileView] = []
  
  init(files: [AudioFile]) {
    self.files = files
    super.init(frame: .zero)
    
    setupStack()
    setupConstraints()
  }
  
  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func setupStack() {
    mainVStack.axis = .vertical
    mainVStack.distribution = .equalSpacing
    
    let rows = 3
    let cols = 4
    for i in 0..<rows {
      let hStack = createHStack()
      
      for j in i*cols..<i*cols+cols {
        let fileView = AudioFileView(file: files[j])
  
        fileViews.append(fileView)
        fileView.isUserInteractionEnabled = false
        fileView.addTarget(self, action: #selector(self.fileClicked(button:)), for: .touchUpInside)
        
        fileView.snp.makeConstraints { make in
          make.height.width.equalTo(40)
        }
        
        hStack.addArrangedSubview(fileView)
      }
      mainVStack.addArrangedSubview(hStack)
    }
  }
  
  func setupConstraints() {
    self.addSubview(self.mainVStack)
    
    mainVStack.snp.makeConstraints { make in
      make.edges.equalToSuperview()
    }
  }
  
  func createHStack() -> UIStackView {
    let stackView = UIStackView()
    stackView.axis = .horizontal
    stackView.distribution = .equalSpacing
    
    /*
     stackView.axis = .horizontal
     stackView.alignment = .fill
     stackView.distribution = .fillEqually
     stackView.spacing = 10
     stackView.backgroundColor = .orange
     */
    
    return stackView
  }
  
  @objc
  func fileClicked(button: AudioFileView) {
    print("1")
    self.fileClickedAction?(button.file)
  }
  
  var movedHasTriggered: Bool = false
  weak var currentFileView: AudioFileView?
  
  override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    super.touchesBegan(touches, with: event)
    self.movedHasTriggered = false
    self.currentFileView = nil
    
    guard let touch = touches.first else {
      return
    }
    
    let position = touch.location(in: self)
    
    for view in self.fileViews {
      let frame = view.superview?.convert(view.frame, to: self) ?? .zero
      if frame.contains(position) {
        self.currentFileView = view
        self.startSelecedAudioFileView(view: view)
        self.audioSpaceView?.touchesMoved(touches, with: event)
        break
      }
    }
  }
  
  func startSelecedAudioFileView(view: AudioFileView) {
    print("SELECT RANDOM")
    let audioSource = AudioSource(
      audio: view.file,
      point: CGPoint(
        x: CGFloat.random(in: 0.1..<0.9),
        y: CGFloat.random(in: 0.1..<0.9)
      ),
      range: 0.5,
      addAnimation: false
    )
    print("PREPARE TO ADD")
    self.audioSpaceView?.space.addSource(audioSource: audioSource)
    print("ADDED")
    self.audioSpaceView?.selectedNode = self.audioSpaceView?.lastAddedNode
  }
  
  override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
    super.touchesMoved(touches, with: event)
    self.audioSpaceView?.touchesMoved(touches, with: event)
    self.movedHasTriggered = true
  }
  
  override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
    print("AudioPickerView_TOUCHES_ENDED")
    super.touchesEnded(touches, with: event)
    self.audioSpaceView?.touchesEnded(touches, with: event)
    self.finishTriggered()
  }
  
  override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
    super.touchesCancelled(touches, with: event)
    self.audioSpaceView?.touchesCancelled(touches, with: event)
    self.finishTriggered()
  }
  
  func finishTriggered() {
    if self.movedHasTriggered == false,
       let fileView = self.currentFileView {
      self.fileClickedAction?(fileView.file)
    }
  }
}
