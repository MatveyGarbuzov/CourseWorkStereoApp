//
//  UserView.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 16.04.2023.
//

import UIKit

class CircleView: UIView {
  override func layoutSubviews() {
    super.layoutSubviews()
    
    self.clipsToBounds = true
    self.layer.cornerRadius = self.frame.size.height / 2
  }
}

class UserView: CircleView {
  override func layoutSubviews() {
    super.layoutSubviews()
    self.backgroundColor = UIColor.Theme.user
    
    layer.masksToBounds = false
    layer.shadowColor = UIColor.Theme.text?.cgColor
    layer.shadowOpacity = 0.1
    layer.shadowRadius = 8
    layer.shadowPath = UIBezierPath(rect: bounds).cgPath
  }
}
