//
//  ProfileImageView.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 18.04.2023.
//

import UIKit

class ProfileImage: UIImageView {

    override func layoutSubviews() {
        super.layoutSubviews()
        
        // Установка круглой формы для изображения
        layer.cornerRadius = bounds.width / 2
        layer.masksToBounds = true
        
        // Обрезание изображения по границам круга
        clipsToBounds = true
    }
}

