//
//  ProfileInfoLabel.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 18.04.2023.
//

import UIKit

enum ProfileLabelType {
  case name
  case signature
  case description
}

class ProfileInfoLabel: UILabel {
  var insets: UIEdgeInsets!
  
  init(insets: UIEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10), type: ProfileLabelType) {
    super.init(frame: .zero)
    self.insets = insets
    self.setup(type: type)
  }
  
  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func setup(type: ProfileLabelType) {
    textAlignment = .center
    numberOfLines = 0
    switch type {
    case .name:
      font = UIFont.CustomFont.interBold(size: 24).font
      textColor = UIColor.Theme.labelText
    case .signature:
      font = UIFont.CustomFont.interLight(size: 16).font
      textColor = UIColor.Theme.profileSubscription
    case .description:
      font = UIFont.CustomFont.interMedium(size: 16).font
      textColor = UIColor.Theme.labelText
    }
      
  }
  
  override func drawText(in rect: CGRect) {
    let insetsRect = rect.inset(by: insets)
    super.drawText(in: insetsRect)
  }
  
  override var intrinsicContentSize: CGSize {
    var contentSize = super.intrinsicContentSize
    contentSize.width += insets.left + insets.right
    contentSize.height += insets.top + insets.bottom
    return contentSize
  }
}

