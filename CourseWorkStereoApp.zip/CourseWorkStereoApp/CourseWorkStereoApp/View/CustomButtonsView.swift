//
//  CustomButtonsView.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 15.04.2023.
//

import UIKit



enum ImageButtonType {
  case arrow
  case heart
  case play
  case pause
  
  var image: UIImage? {
    switch self {
    case .arrow:
      return UIImage(systemName: "arrow.clockwise")
    case .heart:
      return UIImage(systemName: "heart.fill")
    case .play:
      return UIImage(systemName: "play")
    case .pause:
      return UIImage(systemName: "pause")
    }
  }
}

class ImageButton: UIButton {
  var type: ImageButtonType
  
  
  init(type: ImageButtonType) {
    self.type = type
    super.init(frame: .zero)
    
    setImage(type.image, for: .normal)
    imageView?.tintColor = .black
    contentMode = .scaleAspectFit
    
    layer.cornerRadius = 15
    backgroundColor = UIColor.Theme.yellow
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  override func layoutSubviews() {
    super.layoutSubviews()
    
    // Set the image view's frame to fill the entire ImageButton
//    imageView.frame = bounds
  }
}

class DeleteButton: ImageButton {
  override init(type: ImageButtonType) {
    super.init(type: type)
    
//    addTarget(self, action: #selector(deleteButtonPressed(_:)), for: .touchUpInside)
  }
  
//  @objc func deleteButtonPressed(_ sender: DeleteButton) {
//    print("DeletButtonPressed")
//
//    guard let cell = superview?.superview?.superview as? SavedCell else { return }
////    cell.deleteDelegate?.deleteCell(cell, didEndEditingTextFied)
//
//    // AAA
//  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
}

class TextButton: UIButton {
  var title: String
  
  func setup() {
    setTitle(title, for: .normal)
    self.titleLabel?.font = .CustomFont.interMedium(size: 24).font
    setTitleColor(UIColor.black, for: .normal)
    contentHorizontalAlignment = .center
    
    
    layer.cornerRadius = 15
    backgroundColor = UIColor.Theme.yellow
  }
  
  init(title: String = "") {
    self.title = title
    
    super.init(frame: .zero)
    
    setup()
  }
  
  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
}
