//
//  TextField.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 16.04.2023.
//

import UIKit

class CustomTextField: UITextField {
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    setup()
  }
  
  required init?(coder: NSCoder) {
    super.init(coder: coder)
    setup()
  }
  
  // MARK: functions
  func setup() {
    addTarget(self, action: #selector(yourHandler(textField:)), for: .editingChanged)
    addTarget(self, action: #selector(yourHandler2(textField:)), for: .editingDidEnd)
    isUserInteractionEnabled = true
    textColor = UIColor.Theme.text
    font = .CustomFont.interSemiBold(size: 24).font
    
    layer.backgroundColor = UIColor.Theme.yellow?.cgColor
    layer.masksToBounds = true
    layer.cornerRadius = 10
  }
  
  @objc final private func yourHandler(textField: UITextField) {
    print("Text changed.")
  }
  
  @objc final private func yourHandler2(textField: UITextField) {
    print("Text ediditing did end.")
    
    guard let cell = superview?.superview?.superview as? SavedCell else { return }
    cell.changeDelegate?.savedCell(cell, didEndEditingTextField: self)
  }
  
  // Padding for text inside textField
  let padding = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
  
  // MARK: override functions
  override open func textRect(forBounds bounds: CGRect) -> CGRect {
    return bounds.inset(by: padding)
  }
  
  override open func placeholderRect(forBounds bounds: CGRect) -> CGRect {
    return bounds.inset(by: padding)
  }
  
  override open func editingRect(forBounds bounds: CGRect) -> CGRect {
    return bounds.inset(by: padding)
  }
}

