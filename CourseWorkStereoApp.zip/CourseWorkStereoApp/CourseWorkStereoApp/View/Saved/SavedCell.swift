//
//  SavedCellView.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 16.04.2023.
//

import UIKit

protocol ChangeTextFieldDelegate: AnyObject {
  func savedCell(_ cell: SavedCell, didEndEditingTextField textField: CustomTextField)
}

protocol DeleteCellDelegate: AnyObject {
  func deleteCell(at indexPath: IndexPath)
}

class SavedCell: UITableViewCell {
  weak var changeDelegate: ChangeTextFieldDelegate?
  weak var deleteDelegate: DeleteCellDelegate?
  
  var indexPath: IndexPath?
  
  var textField = CustomTextField()
  let playButton = ImageButton(type: .play)
  let saveButton = DeleteButton(type: .heart)//ImageButton(type: .heart)
  
  override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
    super.init(style: style, reuseIdentifier: reuseIdentifier)
    
    let stackView = UIStackView(arrangedSubviews: [textField, playButton, saveButton])
    stackView.axis = .horizontal
    stackView.distribution = .fill
    stackView.spacing = 10
    contentView.addSubview(stackView)
    self.backgroundColor = UIColor.Theme.additionalBG
    
    // Set up constraints for stackView and its subviews...
    stackView.snp.makeConstraints { make in
      make.right.left.equalToSuperview().inset(20)
      make.height.equalToSuperview()
    }
    
    setupConstraints()
    setupTitle()
    setupButton()
  }
  
  func configure(text: String) {
    self.selectionStyle = .none
    self.textField.text = text
  }
  
  private func setupTitle() {
    textField.setup()
  }
  
  private func setupButton() {
    playButton.backgroundColor = UIColor.Theme.yellow
    saveButton.backgroundColor = UIColor.Theme.yellow
  }
  
  private func setupConstraints() {
    self.textField.snp.makeConstraints { make in
      make.width.equalToSuperview().multipliedBy(0.65)
      make.height.equalToSuperview().inset(20)
    }
    
    self.playButton.snp.makeConstraints { make in
      make.height.equalToSuperview().inset(20)
      make.width.equalTo(playButton.snp.height)
    }
    
    self.saveButton.snp.makeConstraints { make in
      make.height.equalToSuperview().inset(20)
      make.width.equalTo(saveButton.snp.height)
    }
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
}
