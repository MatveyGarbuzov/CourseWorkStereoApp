//
//  HomeViewController.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 12.04.2023.
//

import UIKit
import SnapKit
import CoreMotion
import AVFoundation

class HomeViewController: UIViewController {
  let audioSpace = AudioSpace()
  lazy var audioSpaceView = AudioSpaceView(space: self.audioSpace)
  let saveButton = TextButton(title: "Save")
  let resetButton = ImageButton(type: .arrow)
  let pauseButton = ImageButton(type: .pause)
  
  let pickerView = AudioPickerView(files: files)
  
  let motion = CMHeadphoneMotionManager()
  
  var timer: Timer?
  var paused: Bool = false
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    setupConstraints()
    setupButtons()
//    self.restorationIdentifier = "Home"
    
    start()
    
    NotificationCenter.default.addObserver(self, selector: #selector(handleNotification(_:)), name: Notification.Name("NotificationIdentifier"), object: nil)
  }
  
  @objc func handleNotification(_ notification: Notification) {
    if let data = notification.userInfo?["audioSources"] as? [AudioSource] {
      // обрабатываем данные
      passField(field: data)
      print("HANDLED NOTIFICATION")
//      paused = false
      pauseButton.setImage(UIImage(systemName: "pause"), for: .normal)
    }
  }

  
  func start() {
    self.pickerView.audioSpaceView = self.audioSpaceView
    
        
    self.timer = Timer(timeInterval: 0.3, repeats: true) { _ in
    }
    RunLoop.current.add(self.timer!, forMode: .common)
    
    self.pickerView.fileClickedAction = { [weak self] file in
      let audioSource = AudioSource(
        audio: file,
        point: CGPoint(
          x: CGFloat.random(in: 0.1..<0.9),
          y: CGFloat.random(in: 0.1..<0.9)
        ),
        range: 0.5
      )
      self?.audioSpace.addSource(audioSource: audioSource)
    }
    
    guard self.motion.isDeviceMotionAvailable else { return }
    
    self.motion.startDeviceMotionUpdates(to: OperationQueue.main, withHandler: {[weak self] motion, error  in
      guard let motion = motion, error == nil else { return }
      self?.processData(motion)
    })
  }
  
  func setupConstraints() {
    view.backgroundColor = UIColor.Theme.mainBG
    
    view.addSubview(audioSpaceView)
    view.addSubview(pickerView)
    view.addSubview(saveButton)
    view.addSubview(resetButton)
    view.addSubview(pauseButton)
    
    audioSpaceView.snp.makeConstraints { make in
      make.top.equalTo(view.safeAreaLayoutGuide)
      make.left.right.equalToSuperview().inset(30)
      make.height.equalTo(audioSpaceView.snp.width)
      make.centerX.equalToSuperview()
    }
    
    pickerView.snp.makeConstraints { make in
      make.top.equalTo(self.audioSpaceView.snp.bottom).inset(-35)
      make.bottom.equalTo(saveButton.snp.top).inset(-30)
      make.left.right.equalToSuperview().inset(30)
    }

    saveButton.snp.makeConstraints { make in
      make.height.equalTo(60)
      make.left.right.equalToSuperview().inset(100)
      make.bottom.equalTo(view.safeAreaLayoutGuide).inset(70)
      make.centerX.equalToSuperview()
    }
    
    resetButton.snp.makeConstraints { make in
      make.height.equalTo(saveButton.snp.height)
      make.width.equalTo(resetButton.snp.height)
      make.left.equalTo(saveButton.snp.right).offset(20)
      make.bottom.equalTo(view.safeAreaLayoutGuide).inset(70)
    }
    
    pauseButton.snp.makeConstraints { make in
      make.height.equalTo(saveButton.snp.height)
      make.width.equalTo(resetButton.snp.height)
      make.right.equalTo(saveButton.snp.left).offset(-20)
      make.bottom.equalTo(view.safeAreaLayoutGuide).inset(70)
    }
  }
  
  func setupButtons() {
    saveButton.addTarget(self, action: #selector(saveButtonPressed), for: .touchUpInside)
    resetButton.addTarget(self, action: #selector(resetButtonPressed), for: .touchUpInside)
    pauseButton.addTarget(self, action: #selector(pauseButtonPressed), for: .touchUpInside)
  }
  
  @objc func pauseButtonPressed(sender: UIButton) {
    if audioSpace.sources.isEmpty {
      sender.shake()
      return
    }
    print("PAUSED")
    audioSpaceView.space.sources.forEach { source in
      if paused {
        print("1")
        pauseButton.setImage(UIImage(systemName: "pause"), for: .normal)
        source.runAudio()
      } else {
        print("2")
        pauseButton.setImage(UIImage(systemName: "play"), for: .normal)
        source.stopAudio()
      }
    }
    paused.toggle()
  }
  
  @objc func saveButtonPressed(sender: UIButton) {
    if audioSpace.sources.isEmpty {
      sender.shake()
      return
    }
    
    print("Saving this sources: [", terminator: "")
    audioSpace.sources.forEach { AudioSource in
      print(AudioSource.audio.name, terminator: " ")
    }
    print("]")
    Fields.shared.saveField(nameOfField: "UNKNOWN#", fieldOfSources: audioSpace.sources)
    sender.animateInsidePress()
  }
  
  @objc func resetButtonPressed(sender: UIButton) {
    print(audioSpace.sources.count)
    
    while audioSpace.sources.count > 0 {
      audioSpaceView.space.removeSource(audioSource: audioSpace.sources.first!)
    }
    
    print("Clear all sources. Current: \(audioSpace.sources)")
    sender.animateInsidePress()
  }
  
  func processData(_ data: CMDeviceMotion) {
    let angle = CGFloat(data.attitude.yaw)
    self.audioSpace.yaw = angle
    
    let deg = angle * CGFloat(180.0 / Double.pi)
    print(deg)
  }
  
  deinit {
      NotificationCenter.default.removeObserver(self)
  }

}

extension HomeViewController {
  func passField(field: [AudioSource]) {
    print("FIELD PASSED")
      self.audioSpaceView.update(with: field)
    
    print("CURRENT: \(self.audioSpace.sources.map{ $0.audio.name})")
  }
}

var files: [AudioFile] = [
  .baraban,
  .baraban2,
  .bell,
  .bird,
  .chimeBar,
  .dog,
  .forest,
  .guitar,
  .guitar2,
  .piano,
  .solMi,
  .violin
  
]
