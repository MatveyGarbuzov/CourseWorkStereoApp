//
//  ProfileViewController.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 12.04.2023.
//

import UIKit

class ProfileViewController: UIViewController {
  let defaults = UserDefaults.standard
  
  var background = UIView()
  var stackView = UIStackView()
  var profileImage = ProfileImage()
  var profileName = ProfileInfoLabel(type: .name)
  var profileSignature = ProfileInfoLabel(type: .signature)
  var profileDescription = UITextView()
  var profileEditButton = TextButton()
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    setup()
    configure()
  }
  
  func configure() {
    // Add tap gesture recognizer to profile image
    let tapGesture = UITapGestureRecognizer(target: self, action: #selector(profileImageTapped))
    profileImage.isUserInteractionEnabled = true
    profileImage.addGestureRecognizer(tapGesture)
    profileImage.contentMode = .scaleAspectFill
    
    profileImage.image = (Profile.shared.profileInfo?.image ?? UIImage())
    profileName.text = (Profile.shared.profileInfo?.name ?? "Name")
    profileSignature.text = (Profile.shared.profileInfo?.signature ?? "Signature")
    profileDescription.text = (Profile.shared.profileInfo?.description ?? "Description")
    profileEditButton.addTarget(self, action: #selector(editProfile), for: .touchUpInside)
  }
  
  func setup() {
    view.backgroundColor = UIColor.Theme.mainBG
    
    setupBackground()
    setupStack()
    setupConstraints()
  }
  
  func setupBackground() {
    background.backgroundColor = UIColor.Theme.additionalBG
    background.layer.cornerRadius = 15
    background.addDropShadow()
  }
  
  func setupStack() {
    setupDescription()
    stackView = UIStackView(arrangedSubviews: [profileImage, profileName,
                                               profileSignature, profileDescription,
                                               profileEditButton])
    stackView.axis = .vertical
    stackView.alignment = .center
    stackView.spacing = 10
    stackView.setCustomSpacing(0, after: profileName)
  }
  
  func setupDescription() {
    profileDescription.isUserInteractionEnabled = false
    profileDescription.backgroundColor = .clear
    profileDescription.font = UIFont.CustomFont.interMedium(size: 16).font
    profileDescription.textColor = UIColor.Theme.labelText
    profileDescription.textAlignment = .center
  }
  
  func setupConstraints() {
    view.addSubview(background)
    background.snp.makeConstraints { make in
      make.top.equalTo(view.safeAreaLayoutGuide).inset(50)
      make.left.right.equalTo(view.safeAreaLayoutGuide).inset(10)
      make.height.equalTo(view.snp.height).multipliedBy(0.7)
    }
    
    background.addSubview(stackView)
    stackView.snp.makeConstraints { make in
      make.top.equalToSuperview().inset(40)
      make.left.right.bottom.equalToSuperview().inset(15)
    }
    
    profileImage.snp.makeConstraints { make in
      make.width.height.equalTo(130)
    }
    profileImage.backgroundColor = UIColor.Theme.user
    
    [profileName, profileSignature].forEach({ view in
      view.snp.makeConstraints { make in
        make.width.equalToSuperview()
        make.height.equalTo(30)
      }
    })
  
    profileDescription.snp.makeConstraints { make in
      make.width.equalToSuperview().multipliedBy(0.53)
      make.bottom.equalTo(profileEditButton.snp.top).inset(-15)
    }
    
    profileEditButton.snp.makeConstraints { make in
      make.bottom.equalToSuperview().inset(-15)
      make.height.equalTo(40)
      make.width.equalToSuperview().multipliedBy(0.5)
    }
    
    profileEditButton.setTitle("Edit profile", for: .normal)
  }
  
  
  @objc func editProfile() {
    let alertController = UIAlertController(title: "Edit Profile", message: nil, preferredStyle: .alert)
    alertController.addTextField { (textField) in
      textField.placeholder = "Name"
      textField.text = Profile.shared.profileInfo?.name
    }
    alertController.addTextField { (textField) in
      textField.placeholder = "Signature"
      textField.text = Profile.shared.profileInfo?.signature
    }
    alertController.addTextField { (textField) in
      textField.placeholder = "Description"
      textField.text = Profile.shared.profileInfo?.description
    }
    
    // ADD CODE HERE
    
    let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
    
    let saveAction = UIAlertAction(title: "Save", style: .default) { (action) in
      if let nameField = alertController.textFields, let signatureField = alertController.textFields, let descriptionField = alertController.textFields {
        var profileData = Profile.shared.profileInfo ?? Profile.ProfileData(image: nil, name: "", signature: "", description: "")
        profileData.name = nameField[0].text ?? ""
        profileData.signature = signatureField[1].text ?? ""
        profileData.description = descriptionField[2].text ?? ""
        Profile.shared.profileInfo = profileData
        self.profileName.text = profileData.name
        self.profileSignature.text = profileData.signature
        self.profileDescription.text = profileData.description
      }
    }
    
    alertController.addAction(cancelAction)
    alertController.addAction(saveAction)
    
    present(alertController, animated: true, completion: nil)
  }

  @objc func profileImageTapped() {
      // Open user's photo gallery
      let imagePickerController = UIImagePickerController()
      imagePickerController.delegate = self
      imagePickerController.sourceType = .photoLibrary
      present(imagePickerController, animated: true, completion: nil)
    }


  @objc func saveProfileDescription(sender: UIButton) {
    if let textField = sender.superview?.subviews.first(where: { $0 is UITextField }) as? UITextField {
      defaults.set(textField.text, forKey: "profileDescription")
      profileDescription.text = textField.text
    }
    dismiss(animated: true, completion: nil)
  }

}

extension ProfileViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
  func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
    picker.dismiss(animated: true, completion: nil)
    
    if let selectedImage = info[.originalImage] as? UIImage {
      // Set selected image as profile image
      profileImage.image = selectedImage
      
      // Save in User Defaults
      
      Profile.shared.profileInfo?.image = selectedImage
      

    }
  }
  
  func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
    picker.dismiss(animated: true, completion: nil)
  }
}

