//
//  NavigationControllerBase.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 12.04.2023.
//

import UIKit
import SnapKit

class NavigationMenuBaseController: UITabBarController, NavigationMenuDelegate {
  
  
  var customTabBar: TabNavigationMenu!
  var tabBarHeight: CGFloat = 90.0
  
  override func viewDidLoad() {
    super.viewDidLoad()
    self.loadTabBar()
    
    if let savedVC = viewControllers![1] as? SavedViewController {
      savedVC.delegate = self
    }
  }
  
  func loadTabBar() {
    let tabItems: [TabItem] = [.home, .saved, .profile]
    self.setupCustomTabBar(tabItems) { (controllers) in
      self.viewControllers = controllers
    }
    self.selectedIndex = 0 // default our selected index to the first item
  }

  func changeTab(tab: Int) {
    self.selectedIndex = tab
  }
  
  func switchToHomeViewController() {
    customTabBar.switchTab(from: 1, to: 0)
  }
  
  private func setupCustomTabBar(_ items: [TabItem], completion: @escaping ([UIViewController]) -> Void){
    let frame = CGRect(x: tabBar.frame.origin.x, y: tabBar.frame.origin.x, width: tabBar.frame.width, height: tabBarHeight)
    var controllers = [UIViewController]()
    
    tabBar.isHidden = true
    
    customTabBar = TabNavigationMenu(menuItems: items, frame: frame)
    customTabBar.clipsToBounds = true
    customTabBar.itemTapped = self.changeTab
    
    view.addSubview(customTabBar)
    customTabBar.snp.makeConstraints { make in
      make.leading.trailing.bottom.equalTo(tabBar)
      make.width.equalTo(tabBar.frame.width)
      make.height.equalTo(view.snp.height).multipliedBy(0.1)
    }
    
    for i in 0 ..< items.count {
      controllers.append(items[i].viewController) // we fetch the matching view controller and append here
    }
    
    self.view.layoutIfNeeded()
    completion(controllers)
  }
}
