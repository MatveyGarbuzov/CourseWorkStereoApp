//
//  SavedViewController.swift
//  CourseWorkStereoApp
//
//  Created by Matvey Garbuzov on 12.04.2023.
//

import UIKit

protocol NavigationMenuDelegate: AnyObject {
  func switchToHomeViewController()
}

//protocol PlaySavedFieldDelegate: AnyObject {
//  func sendData(data: [AudioSource])
//}

class SavedViewController: UIViewController {
  weak var delegate: NavigationMenuDelegate?
//  weak var playSavedFeildDelegate: PlaySavedFieldDelegate?
  
//  func sendDataToHome() {
//    playSavedFeildDelegate?.sendData(data: dataToSend)
//  }

  
  var background = UIView()
  var tableView = UITableView()
  
  override func viewDidLoad() {
    super.viewDidLoad()
    setup()
    self.restorationIdentifier = "Saved"
  }
  
  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    
    self.tableView.reloadData()
  }
  
  func setup() {
    view.backgroundColor = UIColor.Theme.mainBG
    
    setupTableView()
    setupConstraints()
    setupKeyboard()
  }
  
  private func setupTableView() {
    tableView = UITableView(frame: view.bounds, style: .plain)
    tableView.delegate = self
    tableView.dataSource = self
    tableView.register(SavedCell.self, forCellReuseIdentifier: "SavedCellView")
    
    tableView.backgroundColor = UIColor.Theme.additionalBG
    tableView.layer.cornerRadius = 15
    tableView.separatorColor = UIColor.clear
    
    // Create background for correct shadow
    background.backgroundColor = UIColor.Theme.additionalBG
    background.layer.cornerRadius = 15
    background.addDropShadow()
  }
  
  private func setupConstraints() {
    view.addSubview(background)
    view.addSubview(tableView)
    
    
    tableView.snp.makeConstraints { make in
      make.top.equalTo(view.safeAreaLayoutGuide).inset(50)
      make.left.right.equalTo(view.safeAreaLayoutGuide).inset(10)
      make.height.equalTo(view.snp.height).multipliedBy(0.7)
    }
    
    background.snp.makeConstraints { make in
      make.edges.equalTo(tableView)
    }
  }
  
  private func setupKeyboard() {
    let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
    view.addGestureRecognizer(tap)
  }
  
  @objc func dismissKeyboard() {
    view.endEditing(true)
  }
  
  @objc func deleteButtonTapped(_ sender: UIButton) {
    print("DELETE")
    sender.animateInsidePress()
    // Get the cell that contains the button
    guard let cell = sender.superview?.superview?.superview as? SavedCell else { return }
    
    // Get the index path of the cell
    guard let indexPath = tableView.indexPath(for: cell) else { return }
    
    // Print the row number
    print("Row: \(indexPath.row)")
    
    // Delete local data
    Fields.shared.deleteField(at: indexPath.row)
//    tableView.reloadData()
    tableView.deleteRows(at: [indexPath], with: .fade)
  }
  
  @objc func playButtonTapped(_ sender: UIButton) {
    // Get the cell that contains the button
    guard let cell = sender.superview?.superview?.superview as? SavedCell else { return }
    
    // Get the index path of the cell
    guard let indexPath = tableView.indexPath(for: cell) else { return }
    
    let fieldToPlay = Fields.shared.savedFieldsOfSources[indexPath.row].fieldOfSources
    print("PLAY FIELD #\(indexPath.row)")
    
    // MARK: CHANGE
//    HomeViewController().passField(field: fieldToPlay)
    
    NotificationCenter.default.post(name: Notification.Name("NotificationIdentifier"),
                                    object: nil,
                                    userInfo: ["audioSources" : fieldToPlay])

    

//    playSavedFeildDelegate?.passField(field: fieldToPlay)
    delegate?.switchToHomeViewController()
  }
}

extension SavedViewController: UITableViewDataSource, UITableViewDelegate {
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    Fields.shared.savedFieldsOfSources.count
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "SavedCellView", for: indexPath) as! SavedCell
    
    let savedItem = Fields.shared.savedFieldsOfSources[indexPath.row].nameOfField
    cell.textField.text = savedItem
    cell.indexPath = indexPath
    cell.changeDelegate = self
    
    cell.saveButton.addTarget(self, action: #selector(deleteButtonTapped(_:)), for: .touchUpInside)
    cell.playButton.addTarget(self, action: #selector(playButtonTapped(_:)), for: .touchUpInside)
    
    return cell
  }
  
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    80
  }
}

extension SavedViewController: ChangeTextFieldDelegate {
  func savedCell(_ cell: SavedCell, didEndEditingTextField textField: CustomTextField) {
    
    print("afsjnajfsausf")
    guard let indexPath = tableView.indexPath(for: cell) else { return }
    let newValue = textField.text ?? ""
//    Base.shared.update(savedSourceAtIndex: indexPath.row, withNewValue: newValue)
    let fieldOfSource = Fields.shared.savedFieldsOfSources[indexPath.row].fieldOfSources
    Fields.shared.updateField(nameOfField: newValue, fieldOfSources: fieldOfSource, index: indexPath.row)
  }
}
